package tech.depaul.digitalatm.data.pojo;

public enum ATMOperation {
    DEPOSIT,
    WITHDRAW
}
