package tech.depaul.digitalatm.controllers;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import tech.depaul.digitalatm.TestUtils;
import tech.depaul.digitalatm.config.ATMUserDetails;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SecurityServiceTest {

    @Mock SecurityContext context;
    @Mock Authentication authentication;

    @Test
    void testGetCurrentUser() {
        SecurityContextHolder.setContext(context);
        final SecurityService securityService = new SecurityService();

        when(context.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(new ATMUserDetails(TestUtils.getTestUser()));

        assertThat(securityService.getCurrentUser()).isNotNull();
    }

}
