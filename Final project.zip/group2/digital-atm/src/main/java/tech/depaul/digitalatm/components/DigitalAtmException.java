package tech.depaul.digitalatm.components;

public class DigitalAtmException extends RuntimeException {
    public DigitalAtmException(String message) {
        super(message);
    }
}
