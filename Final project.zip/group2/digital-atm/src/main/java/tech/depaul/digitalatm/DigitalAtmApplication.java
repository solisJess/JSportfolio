package tech.depaul.digitalatm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalAtmApplication {

    public static void main(String[] args) {
        SpringApplication.run(DigitalAtmApplication.class, args);
    }

}
