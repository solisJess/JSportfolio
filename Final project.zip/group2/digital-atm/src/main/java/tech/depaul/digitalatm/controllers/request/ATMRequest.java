package tech.depaul.digitalatm.controllers.request;



public interface ATMRequest {
    String getAmount();
}
