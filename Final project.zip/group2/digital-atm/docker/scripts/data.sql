insert into users values (1, 'Walter', 'White', 'password', 'USER', 'heisenberg');
insert into users values (2, 'Jesse', 'Pinkman', 'password', 'USER', 'capncook');
insert into users values (3, 'Skyler', 'White', 'password', 'USER', 'skylerwhite');
insert into users values (4, 'Hank', 'Schrader', 'password', 'USER', 'hankschrader');
insert into users values (5, 'Gus', 'Fring', 'password', 'USER', 'gusfring');

insert into accounts values (1, 100.00, 1);
insert into accounts values (2, 100.00, 2);
insert into accounts values (3, 100.00, 3);
insert into accounts values (4, 100.00, 4);
insert into accounts values (5, 100.00, 5);
